1. Install nodejs
2. Cài đặt package

`npm install`

3. Sửa setting
revo: {
	deviceId: "2c27d090-6e5f-11ef-9b09-737280dd368f",
	deviceCodeConnect: "bXkta2lkXzI1MTAxODc4NzE0MTI0XzE3MjU4NTQwNTEzMjQ=",
	mqtt_url: 'mqtt://14.248.82.173:1042',
},

4. RUN

`node run.js revo` 

`revo` là tham số đầu vào để chạy cho môi trường nào.