var fs = require('fs');

const get_data_by_key = (key) => {
	let datas = get_data("all_config", {});
	return datas.hasOwnProperty(key) ? datas[key] : null;
}

const set_data_by_key = (key, data) => {
	const file = "data/all_config.json";
	let datas = get_data("all_config", {});
	datas[key] = data;
	fs.writeFileSync(file, JSON.stringify(datas, null, 2));
}

const get_data = (key, defaultData) => {
	const file = "data/"+key+".json";
	defaultData = (typeof defaultData === 'undefined') ? [] : defaultData;
	if (fs.existsSync(file)) {
		let content = fs.readFileSync(file,'utf8');
		return JSON.parse(content);
	} else {
		fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
		return defaultData;
	}
}

const delete_data = (key, conditions) => {
	const file = "data/"+key+".json";
	let datas = get_data(key);
	const eles = findIndexesByAttributes(datas, conditions);
	if (eles.length == 0) {
		return false;
	}
	datas = removeElementsByIndexes(datas, eles);
	fs.writeFileSync(file, JSON.stringify(datas, null, 2));
}
const edit_data = (key, data, conditions) => {
	const file = "data/"+key+".json";
	let datas = get_data(key);
	const eles = findIndexesByAttributes(datas, conditions);
	if (eles.length == 0) {
		return false;
	}
	let index = eles[0];
	Object.assign(datas[index], data);
	fs.writeFileSync(file, JSON.stringify(datas, null, 2));
}

const add_data = (key, data) => {
	const file = "data/"+key+".json";
	let datas = get_data(key);
	datas.push(data);
	fs.writeFileSync(file, JSON.stringify(datas, null, 2));
}

const findElementsByAttributes = (datas, attributes) => {
	return datas.filter(item => 
		Object.entries(attributes).every(([key, value]) => item[key] === value)
	);
};

const findIndexesByAttributes = (datas, attributes) => {
	return datas.map((item, index) => 
		Object.entries(attributes).every(([key, value]) => item[key] === value) ? index : -1
    ).filter(index => index !== -1);
};

const removeElementsByIndexes = (arr, indexes) => {
  return arr.filter((_, index) => !indexes.includes(index));
};

module.exports = {
  get_data,
  delete_data,
  edit_data,
  add_data,
  set_data_by_key,
  get_data_by_key
};