var mqtt = require('mqtt');
var utils = require('./utils');

const device = (process.argv.length >= 3) ? process.argv[2] : "revo";
console.log("device: " + device);
let all_configs = {
	revo: {
		deviceId: "2c27d090-6e5f-11ef-9b09-737280dd368f",
		deviceCodeConnect: "bXkta2lkXzI1MTAxODc4NzE0MTI0XzE3MjU4NTQwNTEzMjQ=",
		mqtt_url: 'mqtt://14.248.82.173:1042',
	},
	me : {
		deviceId: "e75a7230-74e2-11ef-964a-69f67e317cfa",
		deviceCodeConnect: "bXkta2lkXzA5MTYxNjk5NTBfMTcyNzkxOTQ1MDY4MA==",
		mqtt_url: 'mqtt://171.224.244.48:7780',
	},
	phuong : {
		deviceId: "882e6300-7674-11ef-8cc0-1fcbb7684dd1",
		deviceCodeConnect: "bXkta2lkXzA5MTYxNjk2MzFfMTcyNjc0MjgzNDQ2Ng==",
		mqtt_url: 'mqtt://171.224.244.48:7780',
	},
	ti : {
		deviceId: "de9cf520-7634-11ef-8cc0-1fcbb7684dd1",
		deviceCodeConnect: "bXkta2lkXzA5MTYxNjk5NTNfMTcyNjcxNTQ5MTY3Mg==",
		mqtt_url: 'mqtt://171.224.244.48:7780',
	}
}

let configs = all_configs[device];

var client  = mqtt.connect(configs.mqtt_url,{
    username: configs.deviceCodeConnect
});

client.on('connect', function () {
    console.log('Connected: ' + configs.mqtt_url);
	console.log('DeviceId: ' + configs.deviceId);
    client.subscribe('v1/devices/me/rpc/request/+');
});

client.on('message', function (topic, message) {
	
    var requestId = topic.slice('v1/devices/me/rpc/request/'.length);
    console.log('\n\nRequest.id: ' + requestId);
	console.log('\Topic: ', topic);
	let body = message.toString();
	let objMessage = JSON.parse(body);
    console.log('Message Rreceived: ',  objMessage);
	const propName = objMessage.method;
	let res;
	if (typeof utils[propName] === 'function') {
		console.log(`${propName} is called`);
		res = utils[propName](objMessage, configs);
	} else {
		console.log(`${propName} is not a function`);
		res = utils.defaultResponse(objMessage, configs);
	}
	console.log(`Message Sent: `, res);
	client.publish('v1/devices/me/rpc/response/' + requestId, 	JSON.stringify(res));
});
