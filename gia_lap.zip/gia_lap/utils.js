const { get_data, delete_data, edit_data, add_data, set_data_by_key, get_data_by_key } = require('./data_file');

const getRandomCoordinate = (lat, lon) => {
    // Chuyển đổi khoảng cách từ km sang độ
    const earthRadius = 6371; // Bán kính trái đất tính theo km
	const distance = getRandom(3, 6)/10;
    const maxOffset = distance / earthRadius; // Độ dịch chuyển tính theo radian

    // Tạo góc ngẫu nhiên giữa 0 và 2π
    const angle = Math.random() * 1 * Math.PI;

    // Dịch chuyển ngẫu nhiên vĩ độ và kinh độ
    const deltaLat = maxOffset * Math.cos(angle);
    const deltaLon = maxOffset * Math.sin(angle) / Math.cos(lat * Math.PI / 180);

    // Tính toán tọa độ mới
    const newLat = lat + (deltaLat * 180 / Math.PI);
    const newLon = lon + (deltaLon * 180 / Math.PI);

    return {
        lat: newLat,
        lon: newLon
    };
};

const getRandom = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1) + min);
};

const utils = {
	settingDevice: (objMessage, configs) => {
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},

	getFamilyMembers: (objMessage, configs) => {
		return {
			result: get_data('contacts'),
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		}
	},
	
	addFamilyMember: (objMessage, configs) => {
		add_data('contacts', objMessage.params);
		return objMessage.params;
	},
	deleteFamilyMember: (objMessage, configs) => {
		let updateData = objMessage.params;
		delete_data('contacts', { familyMemberIdUpdate: updateData.familyMemberIdUpdate });
		return objMessage.params;
	},
	updateFamilyMember: (objMessage, configs) => {
		let updateData = objMessage.params;
		edit_data('contacts', objMessage.params, { familyMemberIdUpdate: updateData.familyMemberIdUpdate });
		return objMessage.params;
	},

	getSosSetting: (objMessage, configs) => {
		let setting = get_data_by_key("setSosSetting");
		if (setting == null) {
			setting = {
				sos1: "",
				sos2: "",
				sos3: ""
			};
		}
		return {
			result: setting,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	setSosSetting: (objMessage, configs) => {
		set_data_by_key("setSosSetting", objMessage.params);
		return objMessage.params;
	},
	
	addAlarm: (objMessage, configs) => {
		add_data("alarm", objMessage.params);
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	updateAlarm: (objMessage, configs) => {
		let updateData = objMessage.params;
		edit_data('alarm', objMessage.params, { alarmId: updateData.alarmId });
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	getAlarmList: (objMessage, configs) => {
		return {
			result: get_data("alarm"),
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	addClassroomMode: (objMessage, configs) => {
		add_data("class_room", objMessage.params);
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	getClassroomModes: (objMessage, configs) => {
		return {
			result: get_data("class_room"),
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		}
	},
	
	updateClassroomMode: (objMessage, configs) => {
		let updateData = objMessage.params;
		edit_data('class_room', objMessage.params, { id: updateData.id });
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	deleteClassroomMode: (objMessage, configs) => {
		let updateData = objMessage.params;
		delete_data('class_room', { id: updateData.id });
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	trackingPosition: (objMessage, configs) => {
		let mock_localtion = get_data_by_key('mock_localtion');
		if (mock_localtion == null) {
			mock_localtion = "21.00505724076962,105.7921220294769";
		}
		let lat = mock_localtion.split(',')[0]/1;
		let lon = mock_localtion.split(',')[1]/1;
		let newPosition = getRandomCoordinate(lat, lon);
		set_data_by_key('mock_localtion', `${newPosition.lat},${newPosition.lon}`)
		return {
			locationMode: "GPS",
			latitude: newPosition.lat,
			longitude: newPosition.lon,
			altitude: 10,
			reportTime: Date.now(),
			reportReason: "APP_REQUEST",
			address: "Dich Vong, Cau Giay, HN",
			accuracy: 6
		};
	},
	checkHealthSummary: (objMessage, configs) => {

		return {
			"heartRate": 80,
			"stepCount": 784523,
			"walkingDistance": 7.2,
			"caloriesBurned": 450.5,
			"activeTime": 75,
			"sleepTracking": 8,
			"restingHeartRate": 60,
			"activityLevel": "Moderate",
			"airPressure": 1013.25,
			"humidity": 45,
			"temperature": 22.5,
			"altitude": 150
		};
	},
	
	getLocationMode: (objMessage, configs) => {
		let tmp = get_data_by_key("getLocationMode");
		
		if (tmp == null) {
			tmp = {
				"range": "MINUTES_10",
				"startTime": "08:00",
				"endTime": "22:00",
				"repeats": [
				  1,
				  1,
				  1,
				  1,
				  1,
				  0,
				  0
				]
			};
		}
		return {
			"result": tmp,
			"deviceId": configs.deviceId,
			"status": 0,
			"message": "Success"
		};
	},
	setLocationMode: (objMessage, configs) => {
		set_data_by_key("getLocationMode", objMessage.params);
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	getTurnOffSetting: (objMessage, configs) => {
		const old = get_data_by_key("setTurnOffSetting");
		return {
			"result": old ? true : false,
			"deviceId": configs.deviceId,
			"status": 0,
			"message": "Success"
		};
	},
	setTurnOffSetting: (objMessage, configs) => {
		const old = get_data_by_key("setTurnOffSetting");
		set_data_by_key("setTurnOffSetting", old ? false : true);
		return {
			result: old ? false : true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	getDialSetting: (objMessage, configs) => {
		const old = get_data_by_key("setDialSetting");
		return {
			"result": old ? true : false,
			"deviceId": configs.deviceId,
			"status": 0,
			"message": "Success"
		};
	},
	setDialSetting: (objMessage, configs) => {
		const old = get_data_by_key("setDialSetting");
		set_data_by_key("setDialSetting", old ? false : true);
		return {
			result: old ? false : true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	getAllowStrangerCallSetting: (objMessage, configs) => {
		const old = get_data_by_key("setAllowStrangerCallSetting");
		return {
			"result": old ? true : false,
			"deviceId": configs.deviceId,
			"status": 0,
			"message": "Success"
		};
	},
	setAllowStrangerCallSetting: (objMessage, configs) => {
		const old = get_data_by_key("setAllowStrangerCallSetting");
		set_data_by_key("setAllowStrangerCallSetting", old ? false : true);
		return {
			result: old ? false : true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	getVideoCallSetting: (objMessage, configs) => {
		
		return {
			result: get_data_by_key("setVideoCallSetting") ? true : false,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	setVideoCallSetting: (objMessage, configs) => {
		set_data_by_key("setVideoCallSetting", objMessage.params);
		return {
			result: objMessage.params ? true : false,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	
	setMakeSound: (objMessage, configs) => {
		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},

	defaultResponse: (objMessage, configs) => {

		return {
			result: true,
			deviceId: configs.deviceId,
			status: 0,
			message: "Success"
		};
	},
	

};

module.exports = utils;